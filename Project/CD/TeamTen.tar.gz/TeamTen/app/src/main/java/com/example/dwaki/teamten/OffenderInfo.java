package com.example.dwaki.teamten;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class OffenderInfo extends Activity {


    private EditText license;
    private EditText aadhaar;
    private EditText plate;

    private FirebaseDatabase dDatabase;
    private DatabaseReference myRef;

    private Button dbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offender_info);

        dDatabase = FirebaseDatabase.getInstance();
        myRef = dDatabase.getReference().child("Offender_info");


        license = (EditText)findViewById(R.id.license_edit);
        aadhaar = (EditText)findViewById(R.id.aadhaar_edit);
        plate = (EditText)findViewById(R.id.plate_edit);

        dbtn = (Button)findViewById(R.id.submit_offender);



        dbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String lno = license.getText().toString().trim();
                String ano = aadhaar.getText().toString().trim();
                String pno = plate.getText().toString().trim();

                myRef.child("license_number").setValue(lno);
                myRef.child("aadhaar_number").setValue(ano);
                myRef.child("plate_number").setValue(pno);

            }
        });



    }




    //mDatabase = FirebaseDatabase.getInstance().getReference();

    public void next(View view)
    {
        Intent intent = new Intent(this,SectionEnter.class);
        startActivity(intent);
    }
}
