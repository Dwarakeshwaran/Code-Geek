package com.example.dwaki.teamten;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SectionEnter extends Activity {

    private EditText section;

    private FirebaseDatabase dDatabase;
    private DatabaseReference myRef;

    private Button dbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_section_enter);

        dDatabase = FirebaseDatabase.getInstance();
        myRef = dDatabase.getReference().child("Section_Number_info");


        section = (EditText)findViewById(R.id.sectionno_edit);


        dbtn = (Button)findViewById(R.id.submit_sec);

        dbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String sec = section.getText().toString().trim();

                myRef.child("section_number").setValue(sec);
            }
        });

    }

    public void next(View view)
    {
        Intent intent = new Intent(this,OffenceInfo.class);
        startActivity(intent);
    }
}
