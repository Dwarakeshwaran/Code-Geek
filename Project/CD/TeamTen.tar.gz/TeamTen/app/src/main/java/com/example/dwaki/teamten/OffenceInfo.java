package com.example.dwaki.teamten;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class OffenceInfo extends Activity {

    private EditText section;
    private EditText offence;
    private EditText fine;

    private FirebaseDatabase dDatabase;
    private DatabaseReference myRef;

    private Button dbtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offence_info);

        dDatabase = FirebaseDatabase.getInstance();
        myRef = dDatabase.getReference().child("Offence_info");

        section = (EditText)findViewById(R.id.section_edit);
        offence = (EditText)findViewById(R.id.offence_edit);
        fine = (EditText)findViewById(R.id.fine_edit);


        dbtn = (Button)findViewById(R.id.submit_offence);

        dbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String sec = section.getText().toString().trim();
                String off = offence.getText().toString().trim();
                String fn = fine.getText().toString().trim();

                myRef.child("section_number").setValue(sec);
                myRef.child("offence_number").setValue(off);
                myRef.child("fine_number").setValue(fn);

            }
        });

    }

    public void add(View view)
    {
        Intent intent = new Intent(this, SectionEnter.class);
        startActivity(intent);
    }
}
